
  # Collage website page

  This is a code bundle for Collage website page. The original project is available at https://www.figma.com/design/7tjXnPqvRTe7IKYdeIO6Ff/Collage-website-page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  