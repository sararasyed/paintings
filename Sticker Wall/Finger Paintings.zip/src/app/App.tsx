import { useState, useRef, useCallback, useEffect, useLayoutEffect } from "react";
import { Upload, Trash2, Play, Pause } from "lucide-react";

// Coordinate system:
//   x, w  — fraction of boardWidth  (0–1)
//   y      — fraction of boardHeight (0–1) ← always in-bounds on any board shape
//   h      — fraction of boardWidth        ← same unit as w, preserves sticker AR
type Sticker = {
  id: string;
  src: string;
  x: number;
  y: number;
  w: number;
  h: number;
  rotation: number;
  index: number;
  zIndex: number;
};

const STICKER_FILTER_ID = "sticker-trim";
const REF_SIZE = 640;
const MONO = "'JetBrains Mono', monospace";
const MS_PER_STICKER = 900;

export default function App() {
  const [stickers, setStickers] = useState<Sticker[]>([]);
  const [timelinePos, setTimelinePos] = useState(0);
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [dragOffsetFrac, setDragOffsetFrac] = useState({ x: 0, y: 0 });
  const [isDragOver, setIsDragOver] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [boardWidth, setBoardWidth] = useState(520);
  const [boardHeight, setBoardHeight] = useState(520);
  const [isPlaying, setIsPlaying] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const boardRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const stickerIndexRef = useRef(0);
  const nextZIndexRef = useRef(10);
  const rafRef = useRef<number | null>(null);
  const totalRef = useRef(0);
  // Stable refs so RAF/drag callbacks always see current board dimensions
  const boardWidthRef = useRef(520);
  const boardHeightRef = useRef(520);

  useLayoutEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const update = () => {
      const { width, height } = el.getBoundingClientRect();
      const mobile = width < 640;
      const TOOLBAR_H = 44;
      const GAP = 8;
      const PX = mobile ? 16 : 48;
      const PY = mobile ? 12 : 48;

      let bw: number, bh: number;
      if (mobile) {
        bw = Math.max(180, width - PX);
        bh = Math.max(260, height - TOOLBAR_H - GAP - PY);
      } else {
        const sq = Math.max(200, Math.min(width - PX, height - TOOLBAR_H - GAP - PY));
        bw = sq;
        bh = sq;
      }

      setBoardWidth(bw);
      setBoardHeight(bh);
      boardWidthRef.current = bw;
      boardHeightRef.current = bh;
    };
    update();
    const obs = new ResizeObserver(update);
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  const stopPlay = useCallback(() => {
    if (rafRef.current !== null) { cancelAnimationFrame(rafRef.current); rafRef.current = null; }
    setIsPlaying(false);
  }, []);

  const startPlay = useCallback(() => {
    const total = totalRef.current;
    if (total === 0) return;
    stopPlay();
    const duration = total * MS_PER_STICKER;
    const startTime = performance.now();
    setIsPlaying(true);
    setTimelinePos(0);
    const tick = (now: number) => {
      const progress = Math.min((now - startTime) / duration, 1);
      setTimelinePos(totalRef.current * progress);
      if (progress < 1) { rafRef.current = requestAnimationFrame(tick); }
      else { setIsPlaying(false); rafRef.current = null; }
    };
    rafRef.current = requestAnimationFrame(tick);
  }, [stopPlay]);

  useEffect(() => { totalRef.current = stickers.length; }, [stickers.length]);
  useEffect(() => () => { if (rafRef.current !== null) cancelAnimationFrame(rafRef.current); }, []);

  const addStickerFromDataUrl = useCallback((src: string) => {
    const img = new window.Image();
    img.onload = () => {
      const maxPx = REF_SIZE * 0.32;
      let wPx = img.naturalWidth, hPx = img.naturalHeight;
      if (wPx > maxPx || hPx > maxPx) {
        if (wPx >= hPx) { hPx = hPx * maxPx / wPx; wPx = maxPx; }
        else { wPx = wPx * maxPx / hPx; hPx = maxPx; }
      }
      // w and h are fractions of boardWidth (same unit for both axes)
      const BW = boardWidthRef.current;
      const BH = boardHeightRef.current;
      const wFrac = wPx / BW;           // fraction of boardWidth
      const hFrac = hPx / BW;           // fraction of boardWidth (preserves AR)
      const hAsBHFrac = (hPx / BW) * (BW / BH); // h expressed as fraction of boardHeight for placement check
      const margin = 0.05;
      const x = margin + Math.random() * Math.max(0, 1 - wFrac - margin * 2);
      const y = margin + Math.random() * Math.max(0, 1 - hAsBHFrac - margin * 2);
      const currentIndex = stickerIndexRef.current++;
      setStickers(prev => [...prev, {
        id: crypto.randomUUID(), src, x, y, w: wFrac, h: hFrac,
        rotation: (Math.random() - 0.5) * 18,
        index: currentIndex, zIndex: nextZIndexRef.current++,
      }]);
      setTimelinePos(currentIndex + 1);
      stopPlay();
    };
    img.src = src;
  }, [stopPlay]);

  const handleFiles = useCallback((files: FileList | File[]) => {
    for (const file of Array.from(files)) {
      if (!file.type.startsWith("image/")) continue;
      const reader = new FileReader();
      reader.onload = ev => { if (ev.target?.result) addStickerFromDataUrl(ev.target.result as string); };
      reader.readAsDataURL(file);
    }
  }, [addStickerFromDataUrl]);

  useEffect(() => {
    const onPaste = (e: ClipboardEvent) => {
      for (const item of Array.from(e.clipboardData?.items ?? []))
        if (item.type.startsWith("image/")) { const f = item.getAsFile(); if (f) handleFiles([f]); }
    };
    window.addEventListener("paste", onPaste);
    return () => window.removeEventListener("paste", onPaste);
  }, [handleFiles]);

  // Shared drag/touch start logic
  const initDrag = useCallback((clientX: number, clientY: number, id: string) => {
    stopPlay();
    setSelectedId(id);
    const rect = boardRef.current?.getBoundingClientRect();
    if (!rect) return;
    setStickers(prev => {
      const s = prev.find(s => s.id === id);
      if (!s) return prev;
      setDragOffsetFrac({
        x: (clientX - rect.left) / rect.width  - s.x, // fraction of boardWidth
        y: (clientY - rect.top)  / rect.height - s.y, // fraction of boardHeight
      });
      return prev.map(s => s.id === id ? { ...s, zIndex: nextZIndexRef.current++ } : s);
    });
    setDraggingId(id);
  }, [stopPlay]);

  const startDrag = useCallback((e: React.MouseEvent, id: string) => {
    e.preventDefault(); e.stopPropagation();
    initDrag(e.clientX, e.clientY, id);
  }, [initDrag]);

  const startDragTouch = useCallback((e: React.TouchEvent, id: string) => {
    e.stopPropagation();
    initDrag(e.touches[0].clientX, e.touches[0].clientY, id);
  }, [initDrag]);

  // Mouse move/up
  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      if (!draggingId) return;
      const rect = boardRef.current?.getBoundingClientRect();
      if (!rect) return;
      setStickers(prev => prev.map(s => s.id === draggingId
        ? { ...s, x: (e.clientX - rect.left) / rect.width  - dragOffsetFrac.x,
                   y: (e.clientY - rect.top)  / rect.height - dragOffsetFrac.y }
        : s));
    };
    const onUp = () => setDraggingId(null);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    return () => { window.removeEventListener("mousemove", onMove); window.removeEventListener("mouseup", onUp); };
  }, [draggingId, dragOffsetFrac]);

  // Touch move/end
  useEffect(() => {
    const onMove = (e: TouchEvent) => {
      if (!draggingId) return;
      e.preventDefault();
      const rect = boardRef.current?.getBoundingClientRect();
      if (!rect) return;
      const t = e.touches[0];
      setStickers(prev => prev.map(s => s.id === draggingId
        ? { ...s, x: (t.clientX - rect.left) / rect.width  - dragOffsetFrac.x,
                   y: (t.clientY - rect.top)  / rect.height - dragOffsetFrac.y }
        : s));
    };
    const onEnd = () => setDraggingId(null);
    window.addEventListener("touchmove", onMove, { passive: false });
    window.addEventListener("touchend", onEnd);
    return () => { window.removeEventListener("touchmove", onMove); window.removeEventListener("touchend", onEnd); };
  }, [draggingId, dragOffsetFrac]);

  const deleteSelected = useCallback(() => {
    if (!selectedId) return;
    setStickers(prev => {
      const updated = prev.filter(s => s.id !== selectedId).map((s, i) => ({ ...s, index: i }));
      stickerIndexRef.current = updated.length;
      setTimelinePos(updated.length);
      return updated;
    });
    setSelectedId(null);
    stopPlay();
  }, [selectedId, stopPlay]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.key === "Delete" || e.key === "Backspace") && selectedId &&
        !(e.target instanceof HTMLInputElement) && !(e.target instanceof HTMLTextAreaElement))
        deleteSelected();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [selectedId, deleteSelected]);

  const total = stickers.length;
  const visibleStickers = stickers.filter(s => s.index < timelinePos);
  const pct = total > 0 ? Math.min((timelinePos / total) * 100, 100) : 100;
  const onScrub = (val: number) => { stopPlay(); setTimelinePos(Math.max(0, Math.min(total, val))); setSelectedId(null); };

  return (
    <div
      className="flex flex-col h-screen overflow-hidden select-none"
      style={{ fontFamily: MONO, background: "var(--background)" }}
      onClick={() => setSelectedId(null)}
    >
      {/* SVG filter */}
      <svg width="0" height="0" style={{ position: "absolute" }}>
        <defs>
          <filter id={STICKER_FILTER_ID} x="-25%" y="-25%" width="150%" height="150%" colorInterpolationFilters="sRGB">
            <feMorphology in="SourceAlpha" operator="dilate" radius="6" result="white-mask" />
            <feFlood floodColor="#FFFFFF" result="white-flood" />
            <feComposite in="white-flood" in2="white-mask" operator="in" result="white-layer" />
            <feMorphology in="SourceAlpha" operator="dilate" radius="7" result="border-outer" />
            <feComposite in="border-outer" in2="white-mask" operator="out" result="border-ring" />
            <feFlood floodColor="#9B8B76" result="border-flood" />
            <feComposite in="border-flood" in2="border-ring" operator="in" result="border-layer" />
            <feMerge>
              <feMergeNode in="border-layer" />
              <feMergeNode in="white-layer" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
      </svg>

      {/* Board area */}
      <div
        ref={containerRef}
        className="flex-1 flex items-center justify-center overflow-hidden"
        style={{ padding: boardWidth < 400 ? "8px" : "24px" }}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {/* Toolbar */}
          <div style={{ width: boardWidth, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <span style={{ fontSize: 12, fontWeight: 400, letterSpacing: "0.05em", color: "var(--foreground)" }}>
              finger paintings
            </span>
            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              {selectedId && (
                <button
                  onClick={e => { e.stopPropagation(); deleteSelected(); }}
                  style={{
                    display: "flex", alignItems: "center", gap: 4,
                    padding: "4px 10px", borderRadius: 5, fontSize: 10,
                    background: "rgba(255,87,87,0.08)", color: "#C44",
                    border: "1px solid rgba(255,87,87,0.18)", cursor: "pointer", fontFamily: MONO,
                  }}
                >
                  <Trash2 size={10} /> remove
                </button>
              )}
              <button
                onClick={e => { e.stopPropagation(); fileInputRef.current?.click(); }}
                style={{
                  padding: "4px 14px", borderRadius: 5, fontSize: 10,
                  background: "#1C1A2E", color: "rgba(255,255,255,0.8)",
                  border: "none", cursor: "pointer", fontFamily: MONO, letterSpacing: "0.04em",
                }}
              >
                Add
              </button>
              <input ref={fileInputRef} type="file" accept="image/*" multiple style={{ display: "none" }}
                onChange={e => { handleFiles(e.target.files ?? new FileList()); e.target.value = ""; }} />
            </div>
          </div>

          {/* Board */}
          <div
            ref={boardRef}
            style={{
              position: "relative",
              width: boardWidth,
              height: boardHeight,
              background: "#FDFAF4",
              border: "1.5px solid rgba(28,26,46,0.13)",
              boxShadow: "0 2px 24px rgba(28,26,46,0.07)",
              overflow: "hidden",
              cursor: draggingId ? "grabbing" : "default",
              touchAction: "none",
            }}
            onDragOver={e => { e.preventDefault(); setIsDragOver(true); }}
            onDragLeave={() => setIsDragOver(false)}
            onDrop={e => { e.preventDefault(); setIsDragOver(false); handleFiles(e.dataTransfer.files); }}
          >
            {/* Dot grid */}
            <div style={{
              position: "absolute", inset: 0, pointerEvents: "none",
              backgroundImage: "radial-gradient(circle, rgba(28,26,46,0.09) 1px, transparent 1px)",
              backgroundSize: "24px 24px",
            }} />

            {/* Drop overlay */}
            {isDragOver && (
              <div style={{
                position: "absolute", inset: 0, zIndex: 50,
                display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 8,
                background: "rgba(77,150,255,0.07)", border: "1.5px dashed rgba(77,150,255,0.4)",
              }}>
                <Upload size={22} style={{ color: "#4D96FF" }} />
                <span style={{ fontSize: 10, color: "#4D96FF", fontFamily: MONO }}>drop here</span>
              </div>
            )}

            {/* Stickers — all coords in boardWidth units */}
            {visibleStickers.map(sticker => (
              <div
                key={sticker.id}
                style={{
                  position: "absolute",
                  left:   sticker.x * boardWidth,
                  top:    sticker.y * boardHeight,  // y is fraction of boardHeight
                  width:  sticker.w * boardWidth,
                  height: sticker.h * boardWidth,   // h in boardWidth units, preserves AR
                  transform: `rotate(${sticker.rotation}deg)`,
                  zIndex: sticker.zIndex,
                  cursor: draggingId === sticker.id ? "grabbing" : "grab",
                }}
                onMouseDown={e => startDrag(e, sticker.id)}
                onTouchStart={e => startDragTouch(e, sticker.id)}
                onClick={e => { e.stopPropagation(); setSelectedId(sticker.id); }}
              >
                <img
                  src={sticker.src} alt="sticker" draggable={false}
                  style={{
                    width: "100%", height: "100%", objectFit: "contain",
                    filter: `url(#${STICKER_FILTER_ID})`,
                    userSelect: "none", pointerEvents: "none",
                  }}
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Timeline */}
      <div style={{
        height: 52, flexShrink: 0,
        background: "#1C1A2E",
        borderTop: "1.5px solid rgba(255,255,255,0.05)",
        display: "flex", alignItems: "center",
        padding: "0 20px", gap: 12,
      }}>
        <button
          onClick={() => isPlaying ? stopPlay() : startPlay()}
          style={{
            width: 28, height: 28, borderRadius: "50%", flexShrink: 0,
            background: "rgba(255,255,255,0.08)",
            border: "1px solid rgba(255,255,255,0.12)",
            display: "flex", alignItems: "center", justifyContent: "center",
            cursor: "pointer", color: "rgba(255,255,255,0.75)",
          }}
        >
          {isPlaying
            ? <Pause size={10} fill="currentColor" />
            : <Play size={10} fill="currentColor" style={{ marginLeft: 1 }} />}
        </button>

        <div style={{ position: "relative", flex: 1, height: 20, display: "flex", alignItems: "center" }}>
          <div style={{ position: "absolute", width: "100%", height: 2, background: "rgba(255,255,255,0.09)", borderRadius: 2 }} />
          <div style={{ position: "absolute", height: 2, borderRadius: 2, width: `${pct}%`, background: "rgba(255,255,255,0.32)" }} />
          <input
            type="range" min={0} max={total || 1} value={timelinePos} step="any"
            onChange={e => onScrub(parseFloat(e.target.value))}
            style={{ position: "absolute", width: "100%", height: "100%", opacity: 0, cursor: "pointer", zIndex: 3, margin: 0, padding: 0 }}
          />
          {/* Thumb */}
          <div style={{
            position: "absolute",
            left: `calc(${pct}% - 7px)`,
            top: "50%", transform: "translateY(-50%)",
            width: 14, height: 14, borderRadius: "50%",
            background: "#fff", boxShadow: "0 1px 4px rgba(0,0,0,0.25)",
            pointerEvents: "none", zIndex: 4,
          }} />
        </div>
      </div>
    </div>
  );
}
